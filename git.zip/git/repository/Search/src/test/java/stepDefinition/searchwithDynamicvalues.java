package stepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class searchwithDynamicvalues {
	
	WebDriver driver;
	@Given("^User should be on google home page$")
	public void user_should_be_on_google_home_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\MAHABOOBASULTANASYED\\Documents\\Backup Aug1\\Foldertobecopied\\Personal docs\\Selenium\\chromedriver_win32");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.google.com/");
		System.out.println("Successfully launched google page");
	}

	@When("^the search bar is visible$")
	public void the_search_bar_is_visible() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 Boolean googleText = driver.findElement(By.id("n")).isDisplayed();
		 if (googleText == true)
		 {
			 System.out.println("Google Search bar is visible");
		 }
	}

	@Then("^enter the text \"([^\"]*)\"$")
	public void enter_the_text(String arg1, String arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    driver.findElement(By.id("n")).sendKeys(arg1);
	    driver.findElement(By.id("n")).sendKeys(arg2);
	  	}


}
