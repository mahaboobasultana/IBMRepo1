package stepDefinition;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class elearningSite {

	WebDriver driver;
	// TODO Auto-generated method stub
	@Given("^User should be on elearning home page$")
	public void user_should_be_on_elearning_home_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\MAHABOOBASULTANASYED\\Documents\\Backup Aug1\\Foldertobecopied\\Personal docs\\Selenium\\chromedriver_win32");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://elearningm1.upskills.in/");
	   
	}

	@When("^the register form is visible$")
	public void the_register_form_is_visible() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    driver.findElement(By.id("login-block")).isDisplayed();
	}

	
	@Then("^enter the text \"([^\"]*)\"$")
	public void enter_the_text(DataTable table) throws Throwable 
	{
	    // Write code here that turns the phrase above into concrete actions
			List<List<String>> inputData = table.raw();
			driver.findElement(By.xpath("//a[@href=http://elearningm1.upskills.in/main/auth/inscription.php]"));
			driver.findElement(By.id("registration_firstname")).sendKeys(inputData.get(1).get(0));
			driver.findElement(By.id("registration_lastname")).sendKeys(inputData.get(1).get(1));
			driver.findElement(By.id("registration_email")).sendKeys(inputData.get(1).get(2));
			driver.findElement(By.id("username")).sendKeys(inputData.get(1).get(3));
			driver.findElement(By.id("pass1")).sendKeys(inputData.get(1).get(4));
			driver.findElement(By.id("pass2")).sendKeys(inputData.get(1).get(5));
			driver.findElement(By.id("registration_phone")).sendKeys(inputData.get(1).get(6));
			driver.findElement(By.id("registration_official_code")).sendKeys(inputData.get(1).get(8));
			driver.findElement(By.id("extra_skype")).sendKeys(inputData.get(1).get(9));
			driver.findElement(By.id("extra_linkedin_url")).sendKeys(inputData.get(1).get(10));
			driver.findElement(By.id("registration_submit")).click();
			Boolean registration = driver.findElement(By.xpath("//div/div[contains(text(),'Your personal settings have been registered')]")).isDisplayed();
			if (registration == true)
					{
						System.out.println("The registration is successful");
					}
	}
	@Then("^compose email$")
	public void compose_email() throws Throwable
	{
		driver.findElement(By.xpath("//a[@href='http://elearningm1.upskills.in/index.php']")).click();
		driver.findElement(By.linkText("Compose")).click();
		driver.findElement(By.className("select2-search select2-search--inline")).sendKeys("abcd.xyz@email.com");
		driver.findElement(By.id("compose_message_title")).sendKeys("TestEmail");
		driver.findElement(By.xpath("//div[@class='cke_editable cke_editable_themed cke_contents_ltr cke_show_borders']")).sendKeys("Hi Test Email");
		driver.findElement(By.id("file-descrtiption")).sendKeys("Test Email");
		driver.findElement(By.id("compose_message_compose")).click();
		
	}
	@Then("^Edit Profile$")
	public void Edit_Profile() throws Throwable
	{
		driver.findElement(By.linkText("Edit profile")).click();
		driver.findElement(By.id("extra_skype")).sendKeys("mehek@abcd.com");
		driver.findElement(By.id("extra_linkedin_url")).sendKeys("mehek.com");
		driver.findElement(By.id("profile_apply_change")).click();
		Boolean profileChanges = driver.findElement(By.className("Your new profile has been saved")).isDisplayed();
		if (profileChanges == true)
		{
			System.out.println("Changes in the profile saved successfully");
		}
	}

}
