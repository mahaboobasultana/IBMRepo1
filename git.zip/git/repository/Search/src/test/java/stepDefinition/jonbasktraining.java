package stepDefinition;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class jonbasktraining {

	WebDriver driver;
	
	// TODO Auto-generated method stub
	@Given("^User should be on jonbask home page$")
	public void User_should_be_on_jonbask_home_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\MAHABOOBASULTANASYED\\Documents\\Backup Aug1\\Foldertobecopied\\Personal docs\\Selenium\\chromedriver_win32");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.janbasktraining.com/register");
	   
	}

	@When("^the register form is visible$")
	public void the_register_form_is_visible() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    driver.findElement(By.id("registeration_form")).isDisplayed();
	}

	@Then("^enter the details \"([^\"]*)\"$")
	public void enter_the_form(DataTable table) throws Throwable {
		List<List<String>> inputData = table.raw();
	    // Write code here that turns the phrase above into concrete actions
		driver.findElement(By.id("reg_name")).sendKeys(inputData.get(1).get(0));
		driver.findElement(By.id("reg_country")).sendKeys(inputData.get(1).get(1));
		driver.findElement(By.id("reg_mobile")).sendKeys(inputData.get(1).get(2));
		driver.findElement(By.id("reg_course")).sendKeys(inputData.get(1).get(3));
		driver.findElement(By.id("reg_email")).sendKeys(inputData.get(1).get(4));
		driver.findElement(By.id("reg_con_email")).sendKeys(inputData.get(1).get(5));
		driver.findElement(By.id("reg_password")).sendKeys(inputData.get(1).get(6));
		driver.findElement(By.id("reg_con_password")).sendKeys(inputData.get(1).get(7));
		driver.findElement(By.id("reg_tandc")).click();
		driver.findElement(By.id("submitBtn")).click();
	}
}
