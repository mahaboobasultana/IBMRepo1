package stepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GoogleSearch {

	WebDriver driver;
		// TODO Auto-generated method stub
	@Given("^User should be on google home page$")
		public void user_should_be_on_google_home_page() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\MAHABOOBASULTANASYED\\Documents\\Backup Aug1\\Foldertobecopied\\Personal docs\\Selenium\\chromedriver_win32");
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.get("http://www.google.com");
		   
		}

		@When("^the search bar is visible$")
		public void the_search_bar_is_visible() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		    driver.findElement(By.name("n")).isDisplayed();
		}

		@Then("^enter the text$")
		public void enter_the_text() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			driver.findElement(By.name("n")).sendKeys("Selenium");
		}
		
		@Then("^enter the text \"([^\"]*)\"$")
		public void enter_the_text(String arg1) throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			driver.findElement(By.name("n")).sendKeys(arg1);
		}


	
	

}
